﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vesela_Apostolova_2101681070__Deyan_Guzelev_2101681075
{
    public partial class RPS : Form
    {
        Random random = new Random();
        public RPS()
        {
            InitializeComponent();
        }

        private void btnPlay1_Click(object sender, EventArgs e)
        {
            

            int computerTurn =  random.Next(1, 4);
            int playerTurn = random.Next(1, 4);

            switch (computerTurn)
            {
                case 1:
                    pictureBox1.ImageLocation = @"C:\Users\Vesela Apostolova\Desktop\IT\RockPaperScisiors\rock.png";
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case 2:
                    pictureBox1.ImageLocation = @"C:\Users\Vesela Apostolova\Desktop\IT\RockPaperScisiors\paper.png";
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case 3:
                    pictureBox1.ImageLocation = @"C:\Users\Vesela Apostolova\Desktop\IT\RockPaperScisiors\scissiors.png";
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                default:
                    pictureBox1.ImageLocation = @"C:\Users\Vesela Apostolova\Desktop\IT\RockPaperScisiors\rock.png";
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
            }
            switch (playerTurn)
            {

                case 1:
                    pictureBox2.ImageLocation = @"C:\Users\Vesela Apostolova\Desktop\IT\RockPaperScisiors\rock.png";
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case 2:
                    pictureBox2.ImageLocation = @"C:\Users\Vesela Apostolova\Desktop\IT\RockPaperScisiors\paper.png";
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case 3:
                    pictureBox2.ImageLocation = @"C:\Users\Vesela Apostolova\Desktop\IT\RockPaperScisiors\scissiors.png";
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                default:
                    pictureBox2.ImageLocation = @"C:\Users\Vesela Apostolova\Desktop\IT\RockPaperScisiors\rock.png";
                    pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
            }
            determWinner(computerTurn, playerTurn);
        }

        private void determWinner(int computerScore, int playerScore)
        {
            if (computerScore == 1 && playerScore == 2)
            {
                label1.Text = "The Computer win!";
                label1.ForeColor = Color.Red;
            }
            else if (computerScore == 1 && playerScore == 3)//rock>scissors
            {
                label1.Text = "The Computer win!";
                label1.ForeColor = Color.Red;
            }
            else if (computerScore == 2 && playerScore == 1)
            {
                label1.Text = "You win!";
                label1.ForeColor = Color.Red;

            }
            else if (computerScore == 2 && playerScore == 3)
            {
                label1.Text = "You win!";
                label1.ForeColor = Color.Red;
            }
            else if (computerScore == 3 && playerScore == 1)
            {
                label1.Text = "You win!";
                label1.ForeColor = Color.Red;
            }
            else if (computerScore == 3 && playerScore == 2)
            {
                label1.Text = "The Computer wins!";
                label1.ForeColor = Color.Red;
            }
            else
            {
                label1.Text = "Draw!";
                label1.ForeColor = Color.Red;

            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The players may count aloud to three, or speak the name of the game (e.g. Rock Paper! Scissors!), either raising one hand in a fist and swinging it down with each syllable or holding it behind their back. " +
                "They then throw  by extending it towards their opponent. Variations include a version where players throw immediately on the third count (thus throwing on the count of Scissors!)," +
                " or a version where they shake their hands three times before throwing.", "Rock,Paper,Scissors", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

