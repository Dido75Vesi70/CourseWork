﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Vesela_Apostolova_2101681070__Deyan_Guzelev_2101681075
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            StreamWriter sw = File.CreateText(@"..\usernames.txt");
            try
            {
                sw.Write(textBox1.Text);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                sw.Close();
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (rbRPS.Checked)
            {
                RPS frm3 = new Vesela_Apostolova_2101681070__Deyan_Guzelev_2101681075.RPS();
                frm3.Show();
            }
        }

        private void rbTTT_CheckedChanged(object sender, EventArgs e)
        {
            if (rbTTT.Checked)
            {
                TTT frm4 = new Vesela_Apostolova_2101681070__Deyan_Guzelev_2101681075.TTT();
                frm4.Show();
            }
        }
    }
}
